import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { Movie } from "../models/movie";
import { MovieService } from "../services/movie.service";


@Injectable()
export class MovieResolver implements Resolve<Movie>{
    
    constructor(private movieService:MovieService){}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Movie | Observable<Movie> | Promise<Movie> {
        
        var movieId=route.params.id;
        return this.movieService.getMovieById(movieId);
    }

}
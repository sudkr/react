import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Movie } from '../models/movie';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class MovieService {

    private readonly API_URL = "http://localhost:5000/api/movies";

    constructor(private http: Http) { }

    public getTopMovies(count: number): Observable<Movie[]> {
        return this.http.get(`${this.API_URL}/latest/${count}`)
            .map((resp: Response) => resp.json())
            .catch(err => Observable.throw(err));
    }

    public getMovieById(id): Observable<Movie> {
        return this.http.get(`${this.API_URL}/${id}`)
            .map((resp: Response) => resp.json())
            .catch(err => Observable.throw(err));
    }

    public getCategories(): string[] {
        return ['Bollywood', 'Mollywood', 'Kollywood', 'Tollywood', 'Hollywood'];
    }

    public addMovie(movie: FormData): Observable<any> {
        return this.http.post(this.API_URL, movie)
            .map((res: Response) => res.json())
            .catch(err => Observable.throw(err));
    }

    public updateMovie(id: number, movie: FormData): Observable<any> {
        return this.http.put(`${this.API_URL}/${id}`, movie)
            .map((res: Response) => res.json())
            .catch(err => Observable.throw(err));
    }
}

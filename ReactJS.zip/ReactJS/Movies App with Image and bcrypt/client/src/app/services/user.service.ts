import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LocalStorageService } from 'ngx-webstorage';

import { User } from '../models/user';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/observable/of';


@Injectable()
export class UserService {

    private API_URL: string = "http://localhost:5000/api/users";

    constructor(private http: Http, private localStorageService: LocalStorageService) { }

    public register(user: User): Observable<any> {
        let url = `${this.API_URL}/register`;
        let headers: Headers = new Headers({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
        return this.http.post(url, user, options)
            .map((resp: Response) => resp.json())
            .catch(err => Observable.throw(err));
    }

    public login(user: User): Observable<any> {
        let url = `${this.API_URL}/login`;
        let headers: Headers = new Headers({ 'Content-Type': 'application/json' });
        let options: RequestOptions = new RequestOptions({ headers: headers });
        return this.http.post(url, user, options)
            .map((resp: Response) => resp.json())
            .catch(err => Observable.throw(err));
    }

    public isValidUser(): Observable<boolean> {
        let username = this.localStorageService.retrieve("username");

        if (username != null && username != "") {
            return Observable.of(true);
        } else {
            return Observable.of(false);
        }
    }

    public getUserName(): string {
        let username = this.localStorageService.retrieve("username");
        return (username && username != "") ? username : undefined;
    }

    public logout(): void {
        this.localStorageService.clear("username");
    }
}

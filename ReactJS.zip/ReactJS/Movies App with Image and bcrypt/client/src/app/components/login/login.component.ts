import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    private form:FormGroup;
    private alertMessage="";

    constructor(private fb:FormBuilder, 
        private router:Router,
        private userService:UserService,
        private localStorageService:LocalStorageService) { }

    ngOnInit() {
        this.form=this.fb.group({
            username:['', Validators.compose([Validators.required, Validators.minLength(6)])],
            password:['',Validators.compose([Validators.required, Validators.minLength(6)])],
            
        });
    }

    public login(){
        if(this.form.valid){
            var user=new User();
            user.username=this.form.value.username;
            user.password=this.form.value.password;
            this.userService.login(user)
            .subscribe(
                data=>{
                    this.localStorageService.store("username", user.username);
                    this.router.navigate(['/']);
                },
                err=>this.alertMessage="Invalid username/password"
            );
        }else{
            this.alertMessage="Invalid form data";
        }
    }

}

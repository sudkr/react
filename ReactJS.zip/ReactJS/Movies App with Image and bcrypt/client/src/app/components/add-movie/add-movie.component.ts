import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Http, Response } from '@angular/http';
import "rxjs/add/operator/do";
import "rxjs/add/operator/map";
import { MovieService } from '../../services/movie.service';

@Component({
    selector: 'app-add-movie',
    templateUrl: './add-movie.component.html',
    styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent {

    private form: FormGroup;
    private categories:string[];

    constructor(private fb: FormBuilder,
        private http: Http,
        private el: ElementRef,
        private movieService: MovieService) {

        this.categories=this.movieService.getCategories();

        this.form = this.fb.group({
            title: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            actors: ['', Validators.compose([Validators.required, Validators.minLength(5)])],
            directors: ['', Validators.compose([Validators.required, Validators.minLength(5)])],
            writers: ['',],
            music: ['',],
            singers: ['',],
            description: ['',],
            genre: [],
            year: ['', Validators.compose([Validators.required,Validators.min(1950), Validators.max(new Date().getFullYear()+3)])],
            runtime: ['',],
            languages: ['',],
            awards: ['',],
            production: ['',],
            category: ['',],
            poster: ['',],
            trailer: ['',]
        })
    }

    ngOnInit() {
    }

    public add() {

        let posterEl: HTMLInputElement = this.el.nativeElement.querySelector('#poster');
        let trailerEl: HTMLInputElement = this.el.nativeElement.querySelector('#trailer');

        let posterCount: number = posterEl.files.length;
        let trailerCount: number = trailerEl.files.length;
        let formData = new FormData();

        formData.append('title', this.form.value.title);
        formData.append('actors', this.form.value.actors);
        formData.append('directors', this.form.value.directors);
        formData.append('writers', this.form.value.writers);
        formData.append('music', this.form.value.music);
        formData.append('singers', this.form.value.singers);
        formData.append('description', this.form.value.description);
        formData.append('genre', this.form.value.genre);
        formData.append('year', this.form.value.year);
        formData.append('runtime', this.form.value.runtime);
        formData.append('languages', this.form.value.languages);
        formData.append('awards', this.form.value.awards);
        formData.append('production', this.form.value.production);
        formData.append('category', this.form.value.category);

        if (posterCount > 0) {
            formData.append('poster', posterEl.files.item(0));
        }
        if (trailerCount > 0) {
            formData.append('trailer', trailerEl.files.item(0));
        }


        this.movieService.addMovie(formData)
            .subscribe(
                (result) => {console.log("Succes:", result); alert("Success")},
                (error) => console.log("Error:", error)
            );

    }


}

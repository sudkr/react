import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CompareValidator } from '../../validators/compare.validator';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { Router } from '@angular/router';

@Component({
    selector: 'register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

    private form: FormGroup;
    private alertMessage: string = "";

    constructor(private fb: FormBuilder, private router: Router, private userService: UserService) { }

    ngOnInit() {
        let emailPattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        let passwordCtrl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(6)]));
        this.form = this.fb.group({
            fullname: ['', Validators.compose([Validators.required, Validators.minLength(3)])],
            username: ['', Validators.compose([Validators.required, Validators.minLength(6)])],
            email: ['', Validators.compose([Validators.required, Validators.pattern(emailPattern)])],
            password: passwordCtrl,
            confirmPassword: ['', Validators.compose([Validators.required, CompareValidator.compare(passwordCtrl)])]
        });
    }

    public register() {
        let user: User = this.form.value;
        this.userService.register(user)
            .subscribe(
            data => this.router.navigate(['/']),
            err => {
                console.log("Register user error:", err);
                this.alertMessage = "Failed to register user!"
            });
    }

}

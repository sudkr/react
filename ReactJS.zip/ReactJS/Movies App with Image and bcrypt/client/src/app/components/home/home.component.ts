import { Component, OnInit } from '@angular/core';
import { Movie } from '../../models/movie';
import { MovieService } from '../../services/movie.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    
    private movies:Movie[];
    
    constructor(private movieService:MovieService) { }

    ngOnInit() {
        this.movieService.getTopMovies(12)
        .subscribe(
            data=>this.movies=data,
            err=>console.log(err)
        );
    }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from '../../components/home/home.component';
import { AboutComponent } from '../../components/about/about.component';
import { SearchComponent } from '../../components/search/search.component';
import { AddMovieComponent } from '../../components/add-movie/add-movie.component';
import { EditMovieComponent } from '../../components/edit-movie/edit-movie.component';
import { NotFoundComponent } from '../../components/not-found/not-found.component';
import { MovieResolver } from '../../resolvers/movie.resolver';
import { LoginComponent } from '../../components/login/login.component';
import { RegisterComponent } from '../../components/register/register.component';
import { AuthGuard } from '../../guards/auth.guard';

const routes:Routes=[
    { path:'', component:HomeComponent},
    { path:'about', component:AboutComponent},
    { path:'search', component:SearchComponent},
    { path:'add-movie', component:AddMovieComponent, canActivate:[AuthGuard]},
    { path:'edit-movie/:id', component:EditMovieComponent, resolve:{movie:MovieResolver}},
    { path:'login', component:LoginComponent},
    { path:'register', component:RegisterComponent},
    { path:'**', component:NotFoundComponent},
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports:[
        RouterModule
    ],
    declarations: [],
    providers:[
        MovieResolver,
        AuthGuard
    ]
})
export class MovieRouteModule { 

}

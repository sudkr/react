import { AbstractControl, ValidatorFn, Validators } from "@angular/forms";


export class CompareValidator {
    static compare(compareCtrl: AbstractControl): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } => {
            if (Validators.required(control))
                return;
            return compareCtrl.value != control.value ? { 'compare': { value: control.value } } : null;
        };
    }
}
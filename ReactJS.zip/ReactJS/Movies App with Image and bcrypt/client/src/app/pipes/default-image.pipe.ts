import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'defaultImage'
})
export class DefaultImagePipe implements PipeTransform {

    transform(value: string, fallackImageUrl: string): string {
        if(value && value!=""){
            return value;
        }else{
            return fallackImageUrl;
        }
    }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2Webstorage} from 'ngx-webstorage';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { SearchComponent } from './components/search/search.component';
import { AddMovieComponent } from './components/add-movie/add-movie.component';
import { MovieThumbnailComponent } from './components/movie-thumbnail/movie-thumbnail.component';
import { AboutComponent } from './components/about/about.component';
import { EditMovieComponent } from './components/edit-movie/edit-movie.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { MovieRouteModule } from './modules/movie-route/movie-route.module';
import { MovieService } from './services/movie.service';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserService } from './services/user.service';
import { DefaultImagePipe } from './pipes/default-image.pipe';

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
        SearchComponent,
        AddMovieComponent,
        MovieThumbnailComponent,
        AboutComponent,
        EditMovieComponent,
        NotFoundComponent,
        LoginComponent,
        RegisterComponent,
        DefaultImagePipe
    ],
    imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        MovieRouteModule,
        Ng2Webstorage.forRoot({ prefix: 'movies', separator: '|', caseSensitive:true })
    ],
    providers: [
        MovieService,
        UserService
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }

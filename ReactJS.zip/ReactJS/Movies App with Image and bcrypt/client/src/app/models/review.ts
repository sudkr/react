
export class Review{
    public name: string; //reviewer name
    public rating: number;
    public reviewDate: Date;
    public comment: string;
}
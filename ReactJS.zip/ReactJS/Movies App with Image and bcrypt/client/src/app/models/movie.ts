import { Review } from "./review";

export class Movie {
    public title: string;   
    public actors: string;
    public directors: string;
    public writers: string;
    public music: string;
    public singers: string;
    public description: string;
    public year: number;
    public runtime: string;
    public genre: string;
    public languages: string;
    public awards: string;
    public production: string;
    public category:string;
    public poster: string;
    public trailer: string;
    public reviews: Review[];
}

const mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ReviewSchema = new Schema({
    name: { type: String, required: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    reviewDate: { type: Date, required: true },
    comment: { type: String }
});


var MovieSchema = new Schema({
    title: { type: String, required: true, unique: true },    
    actors: { type: String, required: true },
    directors: { type: String, required: true },
    writers: { type: String, required: false },
    music: { type: String, required: false },
    singers: { type: String, required: false },
    description: { type: String, required: true },
    year: { type: String, required: true },
    runtime: { type: String, required: true },
    genre: { type: String, required: true },
    languages: { type: String, required: false },
    awards: { type: String, required: false },
    production: { type: String, required: true },
    category:{type:String, required:true},
    poster: { type: String, required: false },
    trailer: { type: String, required: false },
    reviews: [ReviewSchema]
});

module.exports = mongoose.model('Movie', MovieSchema);
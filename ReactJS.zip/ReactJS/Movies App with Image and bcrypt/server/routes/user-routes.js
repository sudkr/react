
const express = require('express');
var UserSchema=require('../models/user-schema');

var router = express.Router();

//Add a new user
//POST /api/user/register
router.post('/register', (req, res) => {

    var user = new UserSchema(req.body);
    user.save((err, doc) => {
        if (err) {
            res.status(500).json({ message: "Error in user registration", error: err });
        }
        else {
            res.status(200).json({ message: 'User registered successfully', user: doc, location: `/api/user/${doc._id}` });
        }

    });
});

//validate user
//POST /api/user/login
router.post('/login',(req,res)=>{
    var user=new UserSchema(req.body);
    UserSchema.authenticate(user.username, user.password, function(err,user){
        if(err){
            res.status(404).json({message:"User not exists",error:err, loginSuccess:false});
        }
        else{
            res.status(200).json({message:"Login success", user:user, loginSuccess:true})
        }
    });
});

module.exports=router;
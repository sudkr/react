import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ComponentC from './Component/componentC';
import { UserProvider } from './Component/userContext';
import ContextDemo1 from './Component/contextApi/index';
import Login from './Component/login/Login';
import TodoForm from './Component/comp/todo-form';
import ListTodos from './Component/comp/list-todos';
class App extends Component {
  render() {
    return (
      <div className="App">
     {/* <h1>contect Api demo</h1> */}
        {/* <UserProvider value="sud">
        <ComponentC/>
        </UserProvider> */}

        {/* <ContextDemo1/> */}
        <Login/>
        <br/>
        <h1>Add Todo</h1>
        <TodoForm />
        <h1>Todo List</h1>
        <ListTodos />


      </div>
    );
  }
}

export default App;

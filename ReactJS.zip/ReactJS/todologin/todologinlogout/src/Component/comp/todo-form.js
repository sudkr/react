import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addTodo } from '../actions/Todoaction';
class TodoForm extends Component {
    state = { todo: '' }
    
    render() {
        const { todo } = this.state;
        return (
            <form >
                <input type="text" value={todo}
                    onChange={(e) => this.setState({ todo: e.currentTarget.value })} />
                    <button type="button" onClick={() => this.props.addTodo(todo)}>Add</button>
                    
                </form>
    
            )
        }
    }
    // connect(how to connect)(what to connect)
    const mapDispatchToProps = (dispatch) => {
        return {
            addTodo: (data) => dispatch(addTodo(data))
        }
    }
    export default connect(null, mapDispatchToProps)(TodoForm);
        
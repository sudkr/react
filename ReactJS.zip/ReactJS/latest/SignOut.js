import React, { Component } from 'react'

export class SignOut extends Component {
  render() {
    const user =this.props.userData;
    return (
      <div>
                <h3>Welcome {user.userName}</h3>
      </div>
    )
  }
}

export default SignOut

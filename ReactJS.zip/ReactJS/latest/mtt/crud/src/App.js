import React, { Component } from 'react';
import './App.css';
import Login from './Components/Login';

import Create from './Components/Create';
import Get from './Components/Get';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import NavComponent from './NavComponent';
import Update from './Components/Update';
import Home from './Components/Home';
import About from './Components/About';
import Contact from './Components/Contact';
import Gallery from './Components/Gallery';
class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
          <NavComponent />
          <h1>Welcome To Online Shopping Page</h1>
     

          <hr />
          <Switch>
            <Route exact path='/Home' component={Home} />
            <Route exact path='/About' component={About} />
            <Route exact path='/Contact' component={Contact} />
            <Route exact path='/Gallery' component={Gallery} />
            <Route exact path='/create' component={Create} />
            <Route exact path='/Get' component={Get} />
            <Route exact path='/login' component={Login} />

            <Route exact path='/update' component={Update} />
          </Switch>

        </div>
      </Router>
    );
  }
}

export default App;

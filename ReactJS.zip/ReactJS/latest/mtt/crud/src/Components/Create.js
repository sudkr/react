import React, { Component } from "react";
import axios from "axios";
import { Redirect } from "react-router";

export class Create extends Component {
  constructor(props) {
    super(props);
    this.state = ({
      name: "",
      status: "",
      redirect: false
      
    });
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeStatus = this.onChangeStatus.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }
  baseUrl = "http://localhost:3000/todos";
  onSubmit(event) {
    event.preventDefault();
    const todos = {
      name: this.state.name,
      status: this.state.status
    };
    axios
      .post(this.baseUrl, todos)
      .then(response => {
        console.log(response.data);
        alert("added");
      });
    this.setState({
      name: "",
      status: ""
    });
  }

  onChangeName(event) {
    this.setState({
      name: event.target.value
    })
  }
  onChangeStatus(event) {
    this.setState({
      status: event.target.value
    })
  }

 

  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      return <Redirect to="/Get" />;
    }
    return (
      <div className="container">
        <h1>Manage Products</h1>
        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label className="text text-primary"> Name:</label>
            <input
              type="text"
              value={this.state.name}
              onChange={this.onChangeName}
              className="form-control"
            />
          </div>

          <div className="form-group">
            <label className="text text-primary">Cost:</label>
            <input
              type="number"
              value={this.state.status}
              onChange={this.onChangeStatus}
              className="form-control"
            />
          </div>

          <div className="form-group">
            <input type="Submit" className="btn btn-info" value="Add" />
          </div>
        </form>
      </div>
    );
  }
}

export default Create;

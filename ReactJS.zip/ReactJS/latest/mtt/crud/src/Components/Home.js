
import React from 'react'

export class Homes extends React.Component {

    constructor() {

        super();

        this.state = { display: false }

    }

    display() {

        this.setState({ display: !this.state.display })
    }

    render() {

        return (

            <div>

                <h1></h1>

                {

                    <img src={require('./image.jpg')} text-align="left" width="500" height="300" />

                }


            </div>
        )
    }

}
export default Homes;
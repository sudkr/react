import React, { Component } from 'react'

class Gallery extends Component {
    render() {
        return (
            <div>
                <h1>I am from Gallery</h1>

            </div>
        )
    }
}
export default Gallery;
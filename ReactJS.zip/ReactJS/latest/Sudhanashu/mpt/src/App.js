import React, { Component } from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Home from './components/Home';
import About from './components/About';
import Contacts from './components/Contacts';
import Gallery from './components/Gallery';
import Navcomponent from './components/Navcomponent';
import Get from './components/Get';
import Login from './components/Login';
class App extends Component {
  render() {
    return (
      <Router>
      <div className="container">
      <Navcomponent/>

        <hr/>
        <Switch>
          <Route exact path='/Get' component={Get}/> 
          <Route exact path='/login' component={Login}/>
          <Route exact path='/' component={Home}/>
          <Route exact path='/about' component={About}/>
          <Route exact path='/contact' component={Contacts}/>
          <Route exact path='/gallery' component={Gallery}/>
         
        </Switch>

      </div>
      </Router>
    );
  }
}

export default App;

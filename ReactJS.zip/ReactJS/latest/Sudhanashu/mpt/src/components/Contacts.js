import React, { Component } from 'react'

export class Contacts extends Component {
  render() {
    return (
      <div>
      <h1>  I am in contact </h1> 
      </div>
    )
  }
}

export default Contacts

import React, { Component } from "react";
import SignOut from "./SignOut";

export class Login extends Component {
  constructor() {
    super();
    this.state = {
      user: {
        userName: "",
        passWord: ""
      }, //user end

      display: false,
      view: true
    }; //state end
  }

  UpdateState(ctrl, value) {
    const { user } = this.state; //get current state
    user[ctrl] = value; //update the user entered data
    this.setState({ user });
  }

  handleSubmit(e) {
    e.preventDefault();
    alert(`${this.state.user.userName}`);
    this.setState({ display: true });
    this.setState({ view: false });
  }

  render() {
    const { user } = this.state;
    return (
      <div align="center">
        {this.state.view ? (
          <form onSubmit={e => this.handleSubmit(e)}>
            <h3>Login Page</h3>
            <h4>Sign in</h4>
            <label>Username:</label>
            <input
              type="text"
              placeholder="enter your username"
              value={user.userName}
              onChange={e =>
                this.UpdateState("userName", e.currentTarget.value)
              }
            />
            <br />
            <label>Password:</label>
            <input
              type="password"
              placeholder="enter your username"
              value={user.passWord}
              onChange={e =>
                this.UpdateState("passWord", e.currentTarget.value)
              }
            />
            <br />
            <button className="btn btn-primary" type="submit">
              Login
            </button>
          </form>
        ) : null}
        {this.state.display ? <SignOut userData={this.state.user} /> : null}
      </div>
    );
  }
}
export default Login;

import React, { Component } from 'react'

export class Contacts extends Component {
  render() {
    return (
      <div>
        Contact Us....!
      </div>
    )
  }
}

export default Contacts

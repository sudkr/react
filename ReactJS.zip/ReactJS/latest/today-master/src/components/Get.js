import React, { Component } from "react";
import axios from "axios";

export class Get extends Component {
  constructor(props) {
    super(props);
    this.state = {
      products: []
    };
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeCost = this.onChangeCost.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }
  baseUrl = "http://localhost:3000/products";

  onSubmit(event) {
    event.preventDefault();
    const products = {
      name: this.state.name,
      cost: this.state.cost
    };
    axios.post(this.baseUrl, products).then(response => {
      console.log(response.data);
      alert("Product added");
    });
    this.setState({
      name: "",
      cost: ""
    });
  }

  getTodos = () => {
    axios.get(this.baseUrl).then(response => {
      this.setState({ products: response.data });
    });
  };

  onChangeName(event) {
    this.setState({
      name: event.target.value
    });
  }
  onChangeCost(event) {
    this.setState({
      cost: event.target.value
    });
  }

  componentDidMount() {
    this.getTodos();
  }

  render() {
    return (
      <div className="container">
        <h1>Add Product</h1>
        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label className="text text-primary"> Name:</label>
            <input
              type="text"
              value={this.state.name}
              onChange={this.onChangeName}
              className="form-control"
            />
          </div>

          <div className="form-group">
            <label className="text text-primary">Cost:</label>
            <input
              type="text"
              value={this.state.cost}
              onChange={this.onChangeCost}
              className="form-control"
            />
          </div>

          <div className="form-group">
            <input
              type="Submit"
              className="btn btn-primary  btn-md text-center"
            />
          </div>
        </form>

        <div>
          <table className="table table-striped table-responsive table-hover">
            <thead>
              <tr>
                <td> Name</td>
                <td>Cost:</td>
              </tr>
            </thead>

            {this.state.products.map((obj, i) => (
              <tbody>
                <tr key={i}>
                  <td>{obj.name}</td>
                  <td>{obj.cost}</td>
                </tr>
              </tbody>
            ))}
          </table>
        </div>
      </div>
    );
  }
}

export default Get;

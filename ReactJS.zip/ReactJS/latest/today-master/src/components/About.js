import React, { Component } from "react";

export class About extends Component {
  render() {
    return (
      <div>
        <p>
          Capgemini was founded by Serge Kampf in 1967[8] as an enterprise
          management and data processing company. The company was inaugurated as
          the Société pour la Gestion de l'Entreprise et le Traitement de
          l'Information (Sogeti). In 1974 Sogeti acquired Gemini Computers
          Systems, a US company based in New York.[9] In 1975, having made two
          major acquisitions of CAP and Gemini Computer Systems, and following
          resolution of a dispute with the similarly-named CAP UK over the
          international use of the name 'CAP', Sogeti renamed itself as CAP
          Gemini Sogeti.[9] Cap Gemini Sogeti launched US operations in 1981,
          following the acquisition of Milwaukee-based DASD Corporation,
          specializing in data conversion and employing 500 people in 20
          branches throughout the US. Following this acquisition, The U.S.
          Operation was known as Cap Gemini DASD.[10] In 1986, Cap Gemini Sogeti
          acquired the consulting division of US-based CGA Computer to create
          Cap Gemini America.[11][non-primary source needed] In 1991, Gemini
          Consulting was formed through the integration of two management
          consulting firms (United Research and The MAC group)[9]. The Center
          for Business Innovation at Cap Gemini was transformed from an
          institutional university model to a networked research capability
          under the leadership of its Director Christopher Meyer
          (author)[12][13] in 1995. In 1996, the name was simplified to Cap
          Gemini with a new group logo. All operating companies worldwide were
          re-branded to operate as Cap Gemini.[9] Ernst & Young Consulting was
          acquired by Cap Gemini in 2000. It simultaneously integrated Gemini
          Consulting to form Cap Gemini Ernst & Young.[14] In 2002, Cap Gemini
          re-launched its Sogeti brand, creating a new legal entity bearing the
          original name of the company, headquartered in Brussels, Belgium. The
          new company is focused on delivering IT services to a more limited
          range of markets.
        </p>
      </div>
    );
  }
}

export default About;

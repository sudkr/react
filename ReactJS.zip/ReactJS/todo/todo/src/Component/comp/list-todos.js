import React, { Component } from 'react';
import { connect } from 'react-redux';

class ListTodo extends Component {
    render() {
        return (
            <ul>
                {
this.props.todos.map(
    todo => <li key={todo}>{todo}</li>
)
}
</ul>
);
}
}
const mapStateToProps = (state) => {
return {
todos: state
}
}
export default connect(mapStateToProps)(ListTodo);

import React from 'react'
import Mall1 from './mall'
export const MallContext1 = React.createContext();
class ContextDemo1 extends React.Component{
    render()
    {
        const movies=[
            {movie:'Tiger',time:'9pm'},
            {movie:'Cheetah',time:'1pm'},
            {movie:'Lion',time:'5pm'}
        ]
        return(
            <MallContext1.Provider value={movies}>
                <Mall1/>
            </MallContext1.Provider>
        )
    }
}
export default ContextDemo1;
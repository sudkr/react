import React from 'react'
import { MallContext1 } from './index'

const MovieDisplay1 = (props) => {
    return (
        <div>
            <h1>Screen Name</h1>
          
            {
                props.movies.map(
                    n => <li key={n.movie}>{n.movie}
            </li>
            )}
           

            <h1>Screen Timings</h1>
    {props.movies.map((n) => <li>{n.time}</li>)}
        </div>
    )
}
class Screen1 extends React.Component {
    render() {
        return (
            <MallContext1.Consumer>
                {
                    (movies) => <MovieDisplay1 movies={movies} />
                }
            </MallContext1.Consumer>
        )
    }
}
export default Screen1;
import React from 'react'

import Screen1 from './screen'
class Theater1 extends React.Component{
    render(){
        return(
            <div>
                <h1>Theater</h1>
                <Screen1/>
            </div>
        )
    }
}
export default Theater1;
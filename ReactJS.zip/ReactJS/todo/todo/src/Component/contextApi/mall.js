import React from 'react'
import Theater1 from './theater';
class Mall1 extends React.Component{
    render(){
        return(
            <div>
                <h1>Mall</h1>
                <Theater1/>
               
            </div>
        )
    }
}
export default Mall1;
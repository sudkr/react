import React, { Component } from 'react'

 

export class SignOut extends Component {

 

  render() {

    const user =this.props.userData;

    return (

      <div>

                <form onSubmit={e => this.logout()}>

                <h3>Welcome {user.userName}</h3>

                <button className="btn btn-danger" type="submit">

              Logout

            </button>

            </form>

      </div>

    )

  }

}

 

export default SignOut;
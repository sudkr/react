import React from 'react'
import ComponentE from './componentE';
class ComponentC extends React.Component{
  render(){
    return(
      <div>
        <h1>Component C</h1>
        <ComponentE/>
      </div>
    )
  }
}
export default ComponentC;
import React from 'react'
import { UserConsumer } from './userContext';
class ComponentF extends React.Component{
  render(){
    return(
      <div><h1>Component E</h1>
        
        <UserConsumer>
            
      {username=>{
          return <div>Hello {username}   </div>
      }}
        </UserConsumer>
        </div>
    )
  }
}
export default ComponentF;
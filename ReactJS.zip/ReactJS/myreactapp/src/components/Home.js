
import React from 'react'

export class Homes extends React.Component{

    constructor(){

        super();

        this.state={display:false}

    }

    display(){

    this.setState({display:!this.state.display})
 }

    render(){

        return(

            <div>

            <h1>I am from Home</h1>

            {

                this.state.display?<img src={require('./image.jfif')}/>:null

            }
<button onClick={()=>this.display()}>Click</button>

            </div>
 )
}

}
export default Homes;
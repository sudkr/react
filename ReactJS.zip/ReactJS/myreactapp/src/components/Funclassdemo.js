import React from 'react'

const Funclassdemo=()=>{
    return<h1>this is my functional </h1>
}
export default Funclassdemo;
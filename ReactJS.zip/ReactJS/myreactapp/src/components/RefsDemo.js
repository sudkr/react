import React from 'react'

class RefsDemo1 extends React.Component {
    constructor(props) {
        super(props)
        //step1
        this.inputRef = React.createRef();
    }
    //step3
    componentDidMount() {
        this.inputRef.current.focus();
        console.log(this.inputRef);
    }
    render() {
        return (
            <div>
                {/* //step2 */}
                <input type="text" ref={this.inputRef} />
                <button>Click</button>
            </div>
        )
    }
}
export default RefsDemo1;
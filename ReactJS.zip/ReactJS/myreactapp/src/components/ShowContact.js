import React from 'react'

import Contact from './Contact';

class ShowContact extends React.Component {

    render() {

        return (
            <div>
                <h1>Show Contact</h1>
                <table className="table table-bordered">

                    <thead>
                        <tr><th>Contact Name</th>
                            <th>Contact Number</th>
                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                        {this.props.contacts.map((contact) =>

                            <tr
                                key={contact}>

                                <td>{contact.contactname}</td>

                                <td>{contact.contactnumber}</td>
                                <td><button onClick={() => this.props.deleteContact(contact.id)}
                                    className="btn btn-danger">X</button>
                                </td>

                            </tr>

                        )}

                    </tbody>

                </table>
            </div>
        )

    }

}
export default ShowContact;
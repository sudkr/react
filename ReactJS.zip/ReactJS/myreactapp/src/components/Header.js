import React from 'react'

import { Link } from 'react-router-dom';

export const Header = () => {

    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-dark">

            <div className="container-fluid">

                <div className="navbar-header">


                    <Link className="navbar-brand" to="/">Brand</Link>

                </div>

                <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul className="nav navbar-nav">

                        <li className="active"><Link
                            to="/">Home
<span className="sr-only">

                            </span></Link></li>

                        <li><Link to="/about">About</Link></li>
                        <li><Link to="/Form">Form Demo</Link></li>
                        <li><Link to="/Form1">Form Demo1</Link></li>
                        <li><Link to="/Form2">Form Demo2</Link></li>
                        <li><Link to="/RefsDemo">RefsDemo1</Link></li>
                        <li><Link to="/CustomerInfo1">Add</Link></li>
                        <li><Link to="/LifecycleA">Lifecycle</Link></li>
                        <li><Link to="/Contact">View Contacts</Link></li>
                        <li><Link to="/propstype">Props Type</Link></li>
                        




                    </ul>

                    <ul
                        className="nav navbar-nav navbar-right">

                        {/* <li><Link to="/login">Login</Link></li> */}

                    </ul>

                </div>

            </div>

        </nav>

    );

}


export default Header;
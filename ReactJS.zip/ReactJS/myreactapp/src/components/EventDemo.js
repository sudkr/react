import React from 'react'

class EventDemo1 extends React.Component{

    callEvent(){
        console.log('Am from en event');
    }
    render()
    {
        return(
        <button onClick={()=>this.callEvent()}>Event click me:</button>
           )   }
}
export default EventDemo1;
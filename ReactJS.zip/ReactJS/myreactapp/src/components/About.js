import React, { Component } from 'react'

class About extends Component{
    render(){
        return(
            <div>
            <h1>I am from about</h1>
                {/* <img src={require('./image.jfif')} /> */}
            </div>
        )
    }
}
export default About;
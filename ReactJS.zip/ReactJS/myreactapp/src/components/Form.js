import React from 'react'

export class Form extends React.Component {

  constructor(props) {

    super(props)

    this.state = {

      firstname: "",
      lastname: "",
      topic: 'Angular'

    }

  }

  handleSubmit = (event) => {

    console.log(this.state.firstname);

    console.log(this.state.lastname);

    console.log(this.state.topic);

    event.preventDefault();

  }

  handleChangeFirstname = (event) => {

    this.setState({

      firstname: event.target.value

    })

  }

  handleChangeLastname = (event) => {

    this.setState({

      lastname: event.target.value

    })

  }

  handleChangeTopic = (event) => {

    this.setState({

      topic: event.target.value

    })

  }

  render() {

    return (

      <div>

        <h1>Form Demo</h1>

        <form
          onSubmit={this.handleSubmit}>

          <div>

            <label>First Name</label>

            <input
              type="text"
              value={this.state.firstname}

              onChange={this.handleChangeFirstname}></input>

          </div>

          <div>

            <label>Last Name</label>

            <input
              type="text"
              value={this.state.lastname}

              onChange={this.handleChangeLastname}></input>

          </div>

          <div>

            <label>Topic</label>

            <select
              value={this.state.topic}
              onChange={this.handleChangeTopic}>

              <option value="Angular">Angular</option>

              <option
                value="Node">Node</option>

              <option
                value="React">React</option>

            </select>

          </div>

          <button
            type="submit">submit</button>

        </form>

      </div>

    )

  }

}

export default Form;
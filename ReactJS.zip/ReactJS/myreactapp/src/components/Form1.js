import React from 'react';

class Form1 extends React.Component {
    render() {
        const
            myStyle = {
                color: 'black',
                backgroundColor: 'red'
                //c is in caps in bgcolor
            }
        return (
            <div>
                <h1
                    style={myStyle}>
                    Inline style
                  </h1>
            </div>
        );
    }
}
export default Form1;
import React, { Component } from 'react'
class AddContact extends Component {

    //step1

    //create 2 reference veriables 

    contactname = React.createRef();

    contactnumber = React.createRef();

    handleAddConatct = () => {

        let contObject = {

            contactname: this.contactname.current.value,

            contactnumber: this.contactnumber.current.value

        };

        this.props.addContact(contObject)

    }
    render() {

        return (

            <div className="well">
                <h1>Add New Contact</h1>

                <form>

                    {/* attach the ref variables to your input firlds */}

                    Contact Name <input ref={this.contactname} />

                    <br />

                    Conatct Number <input ref={this.contactnumber} />

                    <br />

                    <button onClick={this.handleAddConatct} className="btn btn-success">

                        Add New Contact</button>

                </form>

            </div>

        );

    }

}
export default AddContact;
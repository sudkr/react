import React from 'react';


class Greetingsclasscomponent extends React.Component{

render(props)
{
    return <h1>Hello {this.props.name}</h1>
}
}
export default Greetingsclasscomponent;

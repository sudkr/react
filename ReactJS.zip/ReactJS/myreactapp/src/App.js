import React, { Component } from 'react';

import './App.css';
// import  Welcome from './components/welcome';
// import Funclassdemo from './components/Funclassdemo';
// import Greeting from './components/Greetings';
// import Greetingsclasscomponent from './components/Greetingclasscomponent';
// import NumListClassComp from './components/NumListClassComp';
// import ListDemo from './components/ListDemo';
// import EventDemo1 from './components/EventDemo';
// import PropsDemo from './components/PropDemo'; 
// import Eventpros from './components/event_prop';
// import StateDemo1 from './components/StateDemo';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import About from './components/About';
import Homes from './components/Home';
import Header from './components/Header';
import Form from './components/Form';
import Form1 from './components/Form1';
import Form2 from './components/Form2';
import RefsDemo1 from './components/RefsDemo';
import CustomerInfo1 from './components/CustomerInfo1';
import CustomerDisplay1 from './components/CustomerDisplay1';
import LifecycleA from './components/LifeCycleA';
import LifecycleB from './components/LifeCycleB';
import Contact from './components/Contact';
import AddContact from './components/AddContact';
import ShowContact from './components/ShowContact';
import PropsType from './components/propstype';

class App extends Component {

  render() {
    // let numbers=[11,12,13,14];

    // let user = {
    //   name:"Pawan Panwari",
    //   hobbies:["Sports","Swimming",
    // "Music","Watching movies","Shopping"],
    // };

    return (
      //  <div>
      // {/* <h1>Hello welcome to my app</h1> */}

      //{/* <h2>This is another tag</h2> */}
      // {/* <Welcome/>
      // */}
      // {/* <Funclassdemo/> */}
      //{/* </div>  */}
      // <div className="container">
      // <div className="row">
      // <div className="col-xs-12">
      // {/* <Greeting name="Namaskar" />
      // <Greeting name="India" />
      // <Greeting name="Jai ho" />
      //<Greetingsclasscomponent name="Sudhanshu" />
      // <NumListClassComp numbers={numbers} />
      //<ListDemo name={user.name} age={30} user={user} />
      //<h2>My children</h2>
      //<h2>Hero Children</h2>

      // <EventDemo1/>
      //<PropsDemo name="PropsDemo"/>*/}

      // <Eventpros age={24}/> 
      // <StateDemo1 message="Welcome Guest"/>





      // </div>
      // </div>
      // </div>


      // <div className="App">
      //   <header className="App-header">
      //     <img src={logo} className="App-logo" alt="logo" />
      //     <p>
      //       Edit <code>src/App.js</code> and save to reload.
      //     </p>
      //     <a
      //       className="App-link"
      //       href="https://reactjs.org"
      //       target="_blank"
      //       rel="noopener noreferrer"
      //     >
      //       Learn React
      //     </a>
      //   </header>
      // </div></header>


      //       <BrowserRouter>
      // <div>
      // <ul>
      // <li>
      // <Link to="/">Home</Link>
      // </li>
      // <li>
      // <Link to="/about">About</Link>
      // </li>
      // </ul>
      // <hr />
      // <div >
      // <Switch>
      // <Route exact path="/" component={Homes} />
      // <Route path="/about" component={About} />
      // </Switch>
      // </div>
      // </div>
      // </BrowserRouter>



      <Router>
        <div>

          <Header />

          <div className="container">

            <Switch>

              <Route exact path="/" component={Homes} />

              <Route exact path="/about" component={About} />

              <Route exact path="/Form" component={Form} />
              <Route exact path="/Form1" component={Form1} />
              <Route exact path="/Form2" component={Form2} />
              <Route exact path="/RefsDemo" component={RefsDemo1} />
              <Route exact path="/CustomerInfo1" component={CustomerInfo1} />
              <Route exact path="/CustomerDisplay1" component={CustomerDisplay1} />
              <Route exact path="/LifecycleA" component={LifecycleA} />
              <Route exact path="/LifecycleB" component={LifecycleB} />
              <Route exact path="/Contact" component={Contact} />
              <Route exact path="/AddContact" component={AddContact} />
              <Route exact path="/ShowContact" component={ShowContact} />
              <Route exact path="/propstype" component={PropsType} />
              

            </Switch>

          </div>

        </div>

      </Router>

    )
  }
}

export default App;

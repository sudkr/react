import React, { Component } from 'react';

import Create from './create'
import Get from './Get'
import {BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'

class App extends Component {
  render() {
    return (
      <Router>
     
      <div className="jumbotron">
      <div className="container">
       <center> <h1>Manage Product</h1></center>
        <ul>
          <li><Link to={'/create'} >Add Product</Link></li>
          <li><Link to={'/Get'}>Product List</Link></li>
        </ul>
        <hr/>
        <Switch>
          <Route exact path='/create' component={Create}/>
          <Route exact path='/Get' component={Get}/> 
        </Switch>

      </div> </div >
      </Router>
    );
  }
}

export default App;
